"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { MessageSquare } from "lucide-react"

export function MainNav() {
  const pathname = usePathname()

  return (
    <div className="flex items-center">
      <Link href="/" className="flex items-center space-x-2">
        <MessageSquare className="h-6 w-6" />
        <span className="font-bold inline-block">Simple Forum</span>
      </Link>
    </div>
  )
}


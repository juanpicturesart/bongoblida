"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Separator } from "@/components/ui/separator"
import { ArrowLeft, Heart, MessageCircle, Flag, Share2 } from "lucide-react"

export default function ThreadPage({ params }: { params: { id: string } }) {
  const [replyText, setReplyText] = useState("")
  const [replies, setReplies] = useState(thread.replies)

  const handleSubmitReply = (e: React.FormEvent) => {
    e.preventDefault()
    if (!replyText.trim()) return

    const newReply = {
      id: `reply-${replies.length + 1}`,
      author: "current_user",
      authorName: "You",
      content: replyText,
      postedAt: "Just now",
      likes: 0,
      isLiked: false,
    }

    setReplies([...replies, newReply])
    setReplyText("")
  }

  const toggleLike = (replyId: string) => {
    setReplies(
      replies.map((reply) => {
        if (reply.id === replyId) {
          return {
            ...reply,
            likes: reply.isLiked ? reply.likes - 1 : reply.likes + 1,
            isLiked: !reply.isLiked,
          }
        }
        return reply
      }),
    )
  }

  return (
    <div className="container mx-auto py-10">
      <Link href="/" className="flex items-center text-muted-foreground mb-6 hover:text-foreground">
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to forums
      </Link>

      <Card className="mb-8">
        <CardHeader className="flex flex-row items-start gap-4">
          <Avatar>
            <AvatarImage src={`/placeholder.svg?height=40&width=40`} alt={thread.authorName} />
            <AvatarFallback>{thread.authorName.charAt(0)}</AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <h1 className="text-2xl font-bold mb-2">{thread.title}</h1>
            <div className="flex items-center text-sm text-muted-foreground">
              <span className="font-medium text-foreground">{thread.authorName}</span>
              <span className="mx-2">•</span>
              <span>{thread.postedAt}</span>
              <span className="mx-2">•</span>
              <span>{thread.category}</span>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="prose max-w-none dark:prose-invert">
            <p>{thread.content}</p>
          </div>
        </CardContent>
        <CardFooter className="flex justify-between border-t pt-6">
          <div className="flex items-center gap-6">
            <Button variant="ghost" size="sm" className="flex items-center gap-1">
              <Heart className="h-4 w-4" />
              <span>{thread.likes}</span>
            </Button>
            <Button variant="ghost" size="sm" className="flex items-center gap-1">
              <MessageCircle className="h-4 w-4" />
              <span>{replies.length}</span>
            </Button>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm">
              <Share2 className="h-4 w-4 mr-2" />
              Share
            </Button>
            <Button variant="ghost" size="sm">
              <Flag className="h-4 w-4 mr-2" />
              Report
            </Button>
          </div>
        </CardFooter>
      </Card>

      <h2 className="text-xl font-semibold mb-4">{replies.length} Replies</h2>

      <div className="space-y-6">
        {replies.map((reply) => (
          <Card key={reply.id}>
            <CardHeader className="flex flex-row items-start gap-4 pb-2">
              <Avatar>
                <AvatarImage src={`/placeholder.svg?height=40&width=40`} alt={reply.authorName} />
                <AvatarFallback>{reply.authorName.charAt(0)}</AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <span className="font-medium">{reply.authorName}</span>
                  <span className="text-sm text-muted-foreground">{reply.postedAt}</span>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <p>{reply.content}</p>
            </CardContent>
            <CardFooter className="flex justify-between pt-2">
              <Button
                variant="ghost"
                size="sm"
                className={`flex items-center gap-1 ${reply.isLiked ? "text-primary" : ""}`}
                onClick={() => toggleLike(reply.id)}
              >
                <Heart className={`h-4 w-4 ${reply.isLiked ? "fill-primary" : ""}`} />
                <span>{reply.likes}</span>
              </Button>
              <Button variant="ghost" size="sm">
                <Flag className="h-4 w-4" />
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>

      <Separator className="my-8" />

      <div className="mb-6">
        <h2 className="text-xl font-semibold mb-4">Leave a reply</h2>
        <form onSubmit={handleSubmitReply}>
          <Textarea
            placeholder="Write your reply here..."
            className="mb-4 min-h-[120px]"
            value={replyText}
            onChange={(e) => setReplyText(e.target.value)}
          />
          <Button type="submit" disabled={!replyText.trim()}>
            Post Reply
          </Button>
        </form>
      </div>
    </div>
  )
}

// Sample data - in a real app, this would come from a database
const thread = {
  id: "1",
  title: "Getting started with Next.js",
  category: "Web Development",
  content: `
    I'm new to Next.js and I'm trying to understand how to use the App Router. Can someone explain the basics?

    I've been using React for about a year now, but I'm finding the Next.js documentation a bit overwhelming. 
    
    Specifically, I'm confused about:
    
    1. The difference between page.js, layout.js, and route.js
    2. How server components work compared to client components
    3. Best practices for fetching data
    
    Any help or resources would be greatly appreciated!
  `,
  author: "newbie_dev",
  authorName: "Alex Johnson",
  postedAt: "2 hours ago",
  likes: 8,
  replies: [
    {
      id: "reply-1",
      author: "next_expert",
      authorName: "Sarah Miller",
      content:
        "Welcome to Next.js! The App Router is a new paradigm introduced in Next.js 13. Basically, page.js defines your page content, layout.js wraps multiple pages, and route.js is for API endpoints. Server components render on the server and can't use hooks, while client components (marked with 'use client') work like traditional React components. For data fetching, look into React Server Components which can fetch data without useEffect. Check out the Next.js docs section on data fetching for more details!",
      postedAt: "1 hour ago",
      likes: 12,
      isLiked: false,
    },
    {
      id: "reply-2",
      author: "react_dev",
      authorName: "Michael Chen",
      content:
        "I was in your position a few months ago! I found that the best way to learn is to build something simple. Try creating a basic blog with the App Router. That will help you understand the file structure and how everything works together. Also, check out the Next.js examples on GitHub - they're really helpful.",
      postedAt: "45 minutes ago",
      likes: 5,
      isLiked: false,
    },
    {
      id: "reply-3",
      author: "code_mentor",
      authorName: "Jamie Wilson",
      content:
        "One thing that helped me understand server vs client components was thinking about it this way: if you need interactivity (useState, useEffect, event handlers), use a client component. If you're just displaying data or need to fetch data securely (with API keys), use a server component. The great thing about Next.js is you can mix and match them in the same app!",
      postedAt: "30 minutes ago",
      likes: 7,
      isLiked: false,
    },
  ],
}


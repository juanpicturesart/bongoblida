"use client"

import type React from "react"

import { useState, useMemo } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Clock, Heart, MessageCircle, Search, Send, X } from "lucide-react"

export default function Home() {
  const [messageText, setMessageText] = useState("")
  const [messages, setMessages] = useState(sampleMessages)
  const [searchQuery, setSearchQuery] = useState("")

  // Filter messages based on search query
  const filteredMessages = useMemo(() => {
    if (!searchQuery.trim()) return messages

    const query = searchQuery.toLowerCase()
    return messages.filter(
      (message) => message.content.toLowerCase().includes(query) || message.authorName.toLowerCase().includes(query),
    )
  }, [messages, searchQuery])

  const handleSubmitMessage = (e: React.FormEvent) => {
    e.preventDefault()
    if (!messageText.trim()) return

    const newMessage = {
      id: `msg-${Date.now()}`,
      author: "current_user",
      authorName: "You",
      content: messageText,
      postedAt: "Just now",
      likes: 0,
      isLiked: false,
    }

    setMessages([...messages, newMessage])
    setMessageText("")
  }

  const toggleLike = (messageId: string) => {
    setMessages(
      messages.map((message) => {
        if (message.id === messageId) {
          return {
            ...message,
            likes: message.isLiked ? message.likes - 1 : message.likes + 1,
            isLiked: !message.isLiked,
          }
        }
        return message
      }),
    )
  }

  // Highlight matching text in search results
  const highlightText = (text: string, query: string) => {
    if (!query.trim()) return text

    const regex = new RegExp(`(${query.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")})`, "gi")
    return text.replace(regex, "<mark>$1</mark>")
  }

  return (
    <div className="container mx-auto py-6">
      <div className="grid grid-cols-1 gap-6 md:grid-cols-4">
        {/* Main content area - 3/4 width on desktop */}
        <div className="md:col-span-3">
          <Card className="flex flex-col h-[calc(100vh-140px)]">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between mb-2">
                <h2 className="text-lg font-semibold">Messages</h2>
                <div className="text-sm text-muted-foreground">
                  {searchQuery ? `${filteredMessages.length} results` : `${messages.length} messages`}
                </div>
              </div>
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search messages..."
                  className="pl-8 pr-8"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                {searchQuery && (
                  <Button
                    variant="ghost"
                    size="icon"
                    className="absolute right-1 top-1.5 h-7 w-7"
                    onClick={() => setSearchQuery("")}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                )}
              </div>
            </CardHeader>

            {/* Messages list - scrollable area */}
            <CardContent className="flex-1 overflow-y-auto mb-4 space-y-4 flex flex-col-reverse">
              {filteredMessages.length === 0 ? (
                <div className="flex items-center justify-center h-full">
                  <p className="text-muted-foreground">No messages found matching your search.</p>
                </div>
              ) : (
                [...filteredMessages].reverse().map((message) => (
                  <div key={message.id} className="p-4 border rounded-lg">
                    <div className="flex items-start gap-4 mb-2">
                      <Avatar>
                        <AvatarImage src={`/placeholder.svg?height=40&width=40`} alt={message.authorName} />
                        <AvatarFallback>{message.authorName.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <span className="font-medium">
                            {searchQuery ? (
                              <span
                                dangerouslySetInnerHTML={{
                                  __html: highlightText(message.authorName, searchQuery),
                                }}
                              />
                            ) : (
                              message.authorName
                            )}
                          </span>
                          <div className="flex items-center text-sm text-muted-foreground">
                            <Clock className="mr-1 h-3 w-3" />
                            <span>{message.postedAt}</span>
                          </div>
                        </div>
                        <p className="mt-2">
                          {searchQuery ? (
                            <span
                              dangerouslySetInnerHTML={{
                                __html: highlightText(message.content, searchQuery),
                              }}
                            />
                          ) : (
                            message.content
                          )}
                        </p>
                      </div>
                    </div>
                    <div className="flex justify-start gap-2 ml-14">
                      <Button
                        variant="ghost"
                        size="sm"
                        className={`flex items-center gap-1 ${message.isLiked ? "text-primary" : ""}`}
                        onClick={() => toggleLike(message.id)}
                      >
                        <Heart className={`h-4 w-4 ${message.isLiked ? "fill-primary" : ""}`} />
                        <span>{message.likes}</span>
                      </Button>
                      <Button variant="ghost" size="sm">
                        <MessageCircle className="h-4 w-4 mr-1" />
                        Reply
                      </Button>
                    </div>
                  </div>
                ))
              )}
            </CardContent>

            {/* Post message form - fixed at bottom */}
            <div className="p-4 border-t mt-auto">
              <form onSubmit={handleSubmitMessage} className="flex gap-2">
                <Textarea
                  placeholder="Type your message..."
                  className="min-h-[60px]"
                  value={messageText}
                  onChange={(e) => setMessageText(e.target.value)}
                />
                <Button type="submit" disabled={!messageText.trim()} className="self-end">
                  <Send className="h-4 w-4" />
                  <span className="sr-only">Send</span>
                </Button>
              </form>
            </div>
          </Card>
        </div>

        {/* Sidebar - 1/4 width on desktop */}
        <div className="md:col-span-1">
          <Card>
            <CardHeader>
              <h2 className="text-lg font-semibold">Users Online</h2>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {onlineUsers.map((user) => (
                  <div key={user.id} className="flex items-center gap-2">
                    <div className="relative">
                      <Avatar>
                        <AvatarImage src={`/placeholder.svg?height=32&width=32`} alt={user.name} />
                        <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <span className="absolute bottom-0 right-0 h-2.5 w-2.5 rounded-full bg-green-500 ring-1 ring-background"></span>
                    </div>
                    <span className="text-sm font-medium">{user.name}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

// Sample data - in a real app, this would come from a database
const sampleMessages = [
  {
    id: "msg-1",
    author: "alex_dev",
    authorName: "Alex Johnson",
    content:
      "Has anyone tried the new React Server Components? I'm curious about the performance benefits in real-world applications.",
    postedAt: "5 minutes ago",
    likes: 3,
    isLiked: false,
  },
  {
    id: "msg-2",
    author: "sarah_designer",
    authorName: "Sarah Miller",
    content: "Just finished a new design system for my company. It's amazing how much Figma has improved our workflow!",
    postedAt: "15 minutes ago",
    likes: 7,
    isLiked: false,
  },
  {
    id: "msg-3",
    author: "tech_guru",
    authorName: "Michael Chen",
    content:
      "I'm hosting a workshop on Next.js this weekend. If anyone's interested in learning about App Router and Server Components, let me know!",
    postedAt: "32 minutes ago",
    likes: 12,
    isLiked: false,
  },
  {
    id: "msg-4",
    author: "code_newbie",
    authorName: "Jamie Wilson",
    content:
      "Just started learning web development last month. Any recommendations for good resources on CSS Grid and Flexbox?",
    postedAt: "1 hour ago",
    likes: 5,
    isLiked: false,
  },
  {
    id: "msg-5",
    author: "dev_lead",
    authorName: "Taylor Rodriguez",
    content:
      "Our team just migrated from Redux to Zustand and it's been a game-changer. The codebase is so much cleaner now!",
    postedAt: "2 hours ago",
    likes: 9,
    isLiked: false,
  },
]

const onlineUsers = [
  { id: "user-1", name: "Alex Johnson" },
  { id: "user-2", name: "Sarah Miller" },
  { id: "user-3", name: "Michael Chen" },
  { id: "user-4", name: "Jamie Wilson" },
  { id: "user-5", name: "Taylor Rodriguez" },
  { id: "user-6", name: "Jordan Smith" },
  { id: "user-7", name: "Casey Brown" },
  { id: "user-8", name: "Riley Garcia" },
]

